package com.cg.Exception;

public class InSufficientBalanceException extends Exception {

}
