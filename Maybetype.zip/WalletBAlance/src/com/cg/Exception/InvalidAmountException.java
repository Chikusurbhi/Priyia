package com.cg.Exception;

public class InvalidAmountException  extends Exception{

}
