package com.cg.Exception;

public class NumberNotFoundException extends Exception
{
	
}
