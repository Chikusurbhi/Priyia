package com.cg.beans;

public class Wallet {
	
	int id;
	double balance;
	
	
	
	public Wallet( double balance) {
		super();
		id= (int) (Math.random()*1000);
		this.balance = balance;
	}
	public Wallet()
	{
		
	}
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}
	
}
