package com.cg.dao;

import com.cg.beans.Customer;

public interface WalletInterface {
	
	
	 public boolean save(Customer c);
	  Customer FindByPhoneNumber(String phonenumber);
	

}
