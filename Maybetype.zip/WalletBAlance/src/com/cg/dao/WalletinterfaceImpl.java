package com.cg.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;

public  class WalletinterfaceImpl implements WalletInterface {
	
	
	private Map<String , Customer> nmap ;
	
		public  WalletinterfaceImpl()
		
		{   
			 nmap= new HashMap<String , Customer>();
			
			
			Wallet w= new Wallet(1000000);
	     Customer cus= new Customer("priya","987543210",w);
	     nmap.put(cus.getPhonenumber(), cus);
	     
	     
	     
	     Wallet w1= new Wallet(300000);
	     Customer cus1= new Customer("priyam","8765432109",w1);
	     nmap.put(cus1.getPhonenumber(), cus1);
	     
		   
	     Wallet w2= new Wallet(400000);
	     Customer cus2= new Customer("priyanka","8765432107",w2);
	     nmap.put(cus2.getPhonenumber(), cus2);
			
		}

		@Override
		public boolean save(Customer c) {
			
			if(nmap.containsKey(c.getPhonenumber()))
				return false;
			nmap.put(c.getPhonenumber(),c);
		return true;	
					
			
			// TODO Auto-generated method stub
			
		}

		@Override
		public Customer FindByPhoneNumber(String phonenumber)
		{
			
			
			for(Entry<String,Customer> map:nmap.entrySet())
			
				if(map.getKey().equals(phonenumber))
					return map.getValue();
			
			
			
			// TODO Auto-generated method stub
			return null;
		}
}

		
		
	