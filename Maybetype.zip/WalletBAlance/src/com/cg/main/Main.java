package com.cg.main;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.Exception.InSufficientBalanceException;
import com.cg.Exception.InvalidAmountException;
import com.cg.Exception.NumberNotFoundException;
import com.cg.beans.Customer;
import com.cg.beans.Wallet;
import com.cg.service.walletInterfaceserviceimpl;

public class Main {
	public static void main(String[] args)
			throws InSufficientBalanceException, InvalidAmountException, NumberNotFoundException {
		walletInterfaceserviceimpl impl = new walletInterfaceserviceimpl();

		Scanner sc = new Scanner(System.in);
		System.out.println("1:Enter create Account");
		System.out.println("2:To show balance");
		System.out.println("3:to deposit");
		System.out.println("4:to withdraw");
		System.out.println("5:Exit");
		int s = sc.nextInt();

		switch (s) {
		case 1: {
			System.out.println("Enter the name");
			String k = sc.nextLine();
			sc.next();
			System.out.println("Enter the phone number ");
			String l = sc.nextLine();
			sc.next();
			System.out.println("Enter the amount ");
			double p = sc.nextDouble();
			// create account

			Wallet w = new Wallet(p);
			Customer cus = new Customer(k, l, w);
			  cus = impl.createAccount(k, l, p);
			  
			  Customer cus2= impl.createAccount(k,l , p);
		

			System.out.println("Created account is" + cus);
			

		}

			break;

		// show balance
		case 2: {
			System.out.println("Enter the number you want to check balance");
			String num = sc.next();
			if (num.equals("987543210") || num.equals("8765432109") || num.equals("8765432107")) {
				System.out.println(impl.showBalance(num));

			} else {
				throw new NumberNotFoundException();

			}
		}
			break;

		case 3: {
			System.out.println("Enter the phone number");
			String k = sc.next();
			System.out.println("Enter the amount ");
			double b = sc.nextDouble();
			if (b < 1000) {
				throw new InvalidAmountException();
			}

			else {

				System.out.println(impl.depositAmount(k, b));

			}
		}
			break;

		case 4: {
			System.out.println("Enter the number ");
			String p = sc.next();
			System.out.println("Enter the withdrawl amount");
			double o = sc.nextDouble();
			System.out.println("Enter the balance");
			double m = sc.nextDouble();
			if (o > m) {
				throw new InSufficientBalanceException();
			}

			else {

				System.out.println(impl.withdrawAmount(p, o));

			}
		}

			break;

		case 5: {
			System.exit(0);

		}
		}

	}
}

