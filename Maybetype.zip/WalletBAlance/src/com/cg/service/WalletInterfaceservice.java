package com.cg.service;



import com.cg.beans.Customer;

public interface WalletInterfaceservice {
	
	Customer createAccount(String Name,String PhoneNumber, double Amount);
	public Customer showBalance(String phoneNumber) ;
	public Customer fundTransfer(String sourcephoneNumber,String targetphoneNumber,double  amount);
	public Customer depositAmount(String phoneNumber,double amount) ;
	public Customer withdrawAmount(String phoneNumber,double amount) ;

}
