package com.cg.service;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;
import com.cg.dao.WalletinterfaceImpl;

public class walletInterfaceserviceimpl   implements WalletInterfaceservice {
	
	WalletinterfaceImpl dao= new WalletinterfaceImpl();
	
		
	@Override
	public Customer createAccount(String Name, String PhoneNumber, double Amount) {
		// TODO Auto-generated method stub	
	Wallet w= new Wallet(Amount);
		Customer c= new Customer(Name,PhoneNumber, w);
		
		dao.save(c);
		return c;


	}
@Override
	public Customer showBalance(String phoneNumber) {
	
return dao.FindByPhoneNumber(phoneNumber);





	}

	@Override
	public Customer fundTransfer(String sourcephoneNumber, String targetphoneNumber, double amount) {
		
		Customer tg=dao.FindByPhoneNumber(targetphoneNumber);
		Customer sr= dao.FindByPhoneNumber(sourcephoneNumber);
	tg.getWallet().setBalance(tg.getWallet().getBalance()+amount);
	sr.getWallet().setBalance(sr.getWallet().getBalance()-amount);
	
	
		
		
		return tg;
	}

	@Override
	public Customer depositAmount(String phoneNumber, double amount) {
		
	Customer l  =dao.FindByPhoneNumber(phoneNumber);
	  
	l.getWallet().setBalance(l.getWallet().getBalance()+amount);
	return l;
		
		
		
		// TODO Auto-generated method stub
	
	}

	@Override
	public Customer withdrawAmount(String phoneNumber, double amount) {
		Customer k= dao.FindByPhoneNumber(phoneNumber);
		k.getWallet().setBalance(k.getWallet().getBalance()-amount);
		
		return k;
	}

}
