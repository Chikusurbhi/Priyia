package com.cg.banking.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
	@SpringBootApplication

  @EnableAutoConfiguration
  
  @ComponentScan("com.cg.banking.banking.repo")
  
  @ComponentScan("com.cg.banking.banking.service")
  
  @EntityScan("com.cg.banking.banking.pojo")
 

public class BankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingApplication.class, args);
	}

}
