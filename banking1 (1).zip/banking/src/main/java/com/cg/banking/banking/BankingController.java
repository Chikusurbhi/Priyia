package com.cg.banking.banking;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.banking.banking.pojo.BankingDto;
import com.cg.banking.banking.service.BankingService;


@RestController
public class BankingController {
	
	@Autowired
	BankingService serviceref;
@RequestMapping(method=RequestMethod.GET,value="banking")
	public List<BankingDto> findAll() {
		// TODO Auto-generated method stub
		return serviceref.findAll();
	}
@RequestMapping(method=RequestMethod.POST,value="banking")
	public BankingDto create(@RequestBody BankingDto bankingdto) {
		// TODO Auto-generated method stub
		return serviceref.create(bankingdto);
	}
@RequestMapping(method=RequestMethod.GET,value="banking1")
	public BankingDto findAccountNo(@PathVariable int AccountNo) {
		// TODO Auto-generated method stub
		return serviceref.findAccountNo(AccountNo);
	}
@RequestMapping(method=RequestMethod.PUT,value="/banking/{AccountNo}")
	public BankingDto update(@PathVariable int AccountNo, @RequestBody BankingDto bankingdto) {
		// TODO Auto-generated method stub
		return serviceref.update(AccountNo, bankingdto);
	}
@RequestMapping(method=RequestMethod.DELETE,value="/banking/{AccountNo}")
	public BankingDto delete(@PathVariable int AccountNo) {
		// TODO Auto-generated method stub
		return serviceref.delete(AccountNo);
	}

}
