package com.cg.banking.banking.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank")
public class BankingDto {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="AccntNo")
	private int AccountNo;
	
	@Column(name="AccntHldrName")
	private String accountHolderName;
	
	@Column(name="Balance")
	private double balance;

	public int getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public BankingDto(int accountNo, String accountHolderName, double balance) {
		super();
		AccountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
	}

	public BankingDto() {
		super();
	}
	
	
}
