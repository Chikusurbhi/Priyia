package com.cg.banking.banking.repo;

import java.util.List;

import com.cg.banking.banking.pojo.BankingDto;

public interface BankingRepo {
	
		public List<BankingDto>findAll();
		public BankingDto create (BankingDto bankingdto);
		public BankingDto findAccountNo(int AccountNo);
		public BankingDto update(int AccountNo,BankingDto bankingdto);
		public BankingDto delete(int AccountNo);

}