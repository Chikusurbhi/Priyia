package com.cg.banking.banking.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.cg.banking.banking.pojo.BankingDto;

@Repository
@Transactional
public class BankingRepoImpl implements BankingRepo {
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	@Transactional
	public List<BankingDto> findAll() {
		// TODO Auto-generated method stub
		TypedQuery<BankingDto>query=entitymanager.createQuery("select bank from BankingDto bank ", BankingDto.class );
				//List<BankingDto> list= query.getResultList();
		//System.out.println("inside find all:"+list);
	return query.getResultList();
	}

	@Override
	@Transactional

	public BankingDto create(BankingDto bankingdto) {
		// TODO Auto-generated method stub
		entitymanager.persist(bankingdto);
		return bankingdto;
	}

	@Override
	@Transactional

	public BankingDto findAccountNo(int AccountNo) {
		// TODO Auto-generated method stub
		BankingDto bankingdto=entitymanager.find(BankingDto.class, AccountNo);
		
		return bankingdto;
	}

	@Override
	@Transactional

	public BankingDto update(int AccountNo, BankingDto bankingdto) {
		// TODO Auto-generated method stub
		entitymanager.merge(bankingdto);
		entitymanager.flush();
		
		return bankingdto;
	}

	@Override
	@Transactional

	public BankingDto delete(int AccountNo) {
		// TODO Auto-generated method stub
		BankingDto bank= entitymanager.find(BankingDto.class, AccountNo);
		entitymanager.remove(bank);
		entitymanager.flush();
		return bank;
		
	}
	
	



	

}
