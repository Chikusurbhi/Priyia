package com.cg.banking.banking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.banking.banking.pojo.BankingDto;

@Service
public interface BankingService {
	public List<BankingDto>findAll();
	public BankingDto create (BankingDto bankingdto);
	public BankingDto findAccountNo(int AccountNo);
	public BankingDto update(int AccountNo,BankingDto bankingdto);
	public BankingDto delete(int AccountNo);

}
