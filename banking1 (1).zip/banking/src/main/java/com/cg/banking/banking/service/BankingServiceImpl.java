package com.cg.banking.banking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.banking.pojo.BankingDto;
import com.cg.banking.banking.repo.BankingRepoImpl;

@Service
public class BankingServiceImpl implements BankingService{
	@Autowired
	BankingRepoImpl bankingrepo;

	@Override
	public List<BankingDto> findAll() {
		// TODO Auto-generated method stub
		return bankingrepo.findAll();
	}

	@Override
	public BankingDto create(BankingDto bankingdto) {
		// TODO Auto-generated method stub
		return bankingrepo.create(bankingdto);
	}

	@Override
	public BankingDto findAccountNo(int AccountNo) {
		// TODO Auto-generated method stub
		return bankingrepo.findAccountNo(AccountNo);
	}

	@Override
	public BankingDto update(int AccountNo, BankingDto bankingdto) {
		// TODO Auto-generated method stub
		return bankingrepo.update(AccountNo, bankingdto);
	}

	@Override
	public BankingDto delete(int AccountNo) {
		// TODO Auto-generated method stub
		return bankingrepo.delete(AccountNo);
	}

}
