$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("DemoFeature.feature");
formatter.feature({
  "line": 1,
  "name": "DemoFeature",
  "description": "In order to avoid silly mistakes\r\nAs a math idiot\r\nI want to be told the sum of two numbers",
  "id": "demofeature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 6554451819,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Add two numbers",
  "description": "",
  "id": "demofeature;add-two-numbers",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "I have entered 50 into the calculator",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "I have entered 70 into the calculator",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I press add",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "the result should be 120 on the screen",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "50",
      "offset": 15
    }
  ],
  "location": "StepDefs.i_have_entered_into_the_calculator(int)"
});
formatter.result({
  "duration": 101628154,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "70",
      "offset": 15
    }
  ],
  "location": "StepDefs.i_have_entered_into_the_calculator(int)"
});
formatter.result({
  "duration": 70072,
  "status": "passed"
});
formatter.match({
  "location": "StepDefs.i_press_add()"
});
formatter.result({
  "duration": 22650,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "120",
      "offset": 21
    }
  ],
  "location": "StepDefs.the_result_should_be_on_the_screen(int)"
});
formatter.result({
  "duration": 1221310,
  "status": "passed"
});
formatter.after({
  "duration": 717358530,
  "status": "passed"
});
formatter.uri("wikipage.feature");
formatter.feature({
  "line": 1,
  "name": "test wikipedia search",
  "description": "In orrder to verify result on wikipedia\r\nAs an end user\r\nI want to enter a search string",
  "id": "test-wikipedia-search",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Searching a given term",
  "description": "",
  "id": "test-wikipedia-search;searching-a-given-term",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Enter search term \u0027\u003csearchTerm\u003e\u0027",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Do search",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Multiple results are shown for \u0027\u003cresult\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "test-wikipedia-search;searching-a-given-term;",
  "rows": [
    {
      "cells": [
        "searchTerm",
        "result"
      ],
      "line": 12,
      "id": "test-wikipedia-search;searching-a-given-term;;1"
    },
    {
      "cells": [
        "mercury",
        "Mercury usually refers to:"
      ],
      "line": 13,
      "id": "test-wikipedia-search;searching-a-given-term;;2"
    },
    {
      "cells": [
        "max",
        "Max or MAX may refer to:"
      ],
      "line": 14,
      "id": "test-wikipedia-search;searching-a-given-term;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 4521901832,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Searching a given term",
  "description": "",
  "id": "test-wikipedia-search;searching-a-given-term;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Enter search term \u0027mercury\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Do search",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Multiple results are shown for \u0027Mercury usually refers to:\u0027",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 19
    }
  ],
  "location": "StefDefswikipage.enter_search_term_mercury(String)"
});
formatter.result({
  "duration": 133659677,
  "status": "passed"
});
formatter.match({
  "location": "StefDefswikipage.do_search()"
});
formatter.result({
  "duration": 1595759778,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Mercury usually refers to:",
      "offset": 32
    }
  ],
  "location": "StefDefswikipage.multiple_results_are_shown_for_Mercury_may_refer_to(String)"
});
formatter.result({
  "duration": 143822988,
  "status": "passed"
});
formatter.after({
  "duration": 712083645,
  "status": "passed"
});
formatter.before({
  "duration": 4589206959,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Searching a given term",
  "description": "",
  "id": "test-wikipedia-search;searching-a-given-term;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Enter search term \u0027max\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Do search",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Multiple results are shown for \u0027Max or MAX may refer to:\u0027",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "max",
      "offset": 19
    }
  ],
  "location": "StefDefswikipage.enter_search_term_mercury(String)"
});
formatter.result({
  "duration": 28394843,
  "error_message": "org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d72.0.3626.109)\n  (Driver info: chromedriver\u003d2.46.628402 (536cd7adbad73a3783fdc2cab92ab2ba7ec361e1),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN56001823\u0027, ip: \u002710.102.51.137\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.46.628402 (536cd7adbad73a..., userDataDir: C:\\Users\\P15\\AppData\\Local\\...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:54318}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), rotatable: false, setWindowRect: true, strictFileInteractability: false, takesHeapSnapshot: true, takesScreenshot: true, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unexpectedAlertBehaviour: ignore, unhandledPromptBehavior: ignore, version: 72.0.3626.109, webStorageEnabled: true}\nSession ID: 94b0e858ef85e5d168483e27293e614c\n*** Element info: {Using\u003did, value\u003dsearchInput}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:368)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat StefDefswikipage.enter_search_term_mercury(StefDefswikipage.java:34)\r\n\tat ✽.Given Enter search term \u0027max\u0027(wikipage.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StefDefswikipage.do_search()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Max or MAX may refer to:",
      "offset": 32
    }
  ],
  "location": "StefDefswikipage.multiple_results_are_shown_for_Mercury_may_refer_to(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 739011924,
  "status": "passed"
});
});