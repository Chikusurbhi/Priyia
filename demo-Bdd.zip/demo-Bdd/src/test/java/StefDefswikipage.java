import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StefDefswikipage {
	private WebDriver driver;
	
	@Before
	public void setup(){
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("http://en.wikipedia.org");
	}
		
	@After
	public void tearDown(){
		driver.quit();
	}

	@Given("^Enter search term '(.*?)'$")
	public void enter_search_term_mercury(String searchTerm) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println(searchTerm);
		
		WebElement searchBox =  driver.findElement(By.id("searchInput"));
		searchBox.sendKeys(searchTerm);
//	    throw new PendingException();
	}

	@When("^Do search$")
	public void do_search() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("searching .....");
		WebElement serachButton = driver.findElement(By.id("searchInput"));
		serachButton.submit();
//	    throw new PendingException();
	}

	@Then("^Multiple results are shown for '(.*?)'$")
	public void multiple_results_are_shown_for_Mercury_may_refer_to(String searchResult) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println(searchResult);
		
		WebElement results = driver.findElement(By.cssSelector("div#mw-content-text.mw-content-ltr p"));

		System.out.println(results.getText() + "....");

		Assert.assertTrue(results.getText().startsWith(searchResult));

//	    throw new PendingException();
	}
			
	
	
	
	
	
	
	
	
}