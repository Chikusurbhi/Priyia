import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import jdk.nashorn.internal.runtime.PrototypeObject;

public class abcd {

	public static void main(String[] args) {
		
		WebDriver driver;
		
		System.out.println(System.getProperty("user.dir"));
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		
		WebElement searchBox =  driver.findElement(By.name("q"));
		searchBox.sendKeys("Mercury");
	searchBox.submit();
		System.out.println("Akhil");
		
	}
	
	
	
}
