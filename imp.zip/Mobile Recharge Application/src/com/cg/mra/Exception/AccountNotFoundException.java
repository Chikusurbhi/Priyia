package com.cg.mra.Exception;

public class AccountNotFoundException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
