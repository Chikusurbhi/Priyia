package com.cg.mra.beans;

public class Account {
	
	private String AccountType;
	private String customerName;
	private double accountBalance;
	
	public Account(String accountType, String customerName, double accountBalance)
	{
		
		AccountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}
	public Account()
	{
		
	}
	public String getAccountType() {
		return AccountType;
	}
	public void setAccountType(String accountType) {
		AccountType = accountType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		return "Account [AccountType=" + AccountType + ", customerName=" + customerName + ", accountBalance="
				+ accountBalance + "]";
	}
	
	

}
