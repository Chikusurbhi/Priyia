package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl  implements AccountService{

	AccountDao dao= new AccountDaoImpl();
	
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		return dao.getAccountDetails(mobileNo);
		
		
		// TODO Auto-generated method stu
	}

	@Override
	public double rechargeAccount(String mobileno, double rechargeAmount) {
		return dao.rechargeAccount(mobileno, rechargeAmount);
		
		// TODO Auto-generated method stub
		
	}

}
