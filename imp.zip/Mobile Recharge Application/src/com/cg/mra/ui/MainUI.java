package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.Exception.AccountNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	public static void main(String[] args) throws AccountNotFoundException
	{
		
		
		AccountService service = new AccountServiceImpl();
        System.out.println("1:Account Balance Enquiry");
		System.out.println("2:Recharge Account");
		System.out.println("3:Exit");
		Scanner sc= new Scanner(System.in);
		
		int a=sc.nextInt();
		
		
	switch(a)
	{
	case 1:{
		
		
		System.out.println("Enter the mobile number");
		String k = sc.next();
		if(k.equals("9010210131")||k.equals("9823920123")||k.equals("9932012345")||k.equals("9010210132")||k.equals("90102101033"))
		{
			System.out.println(service.getAccountDetails(k));
			
		}
		
		else
		{
			throw  new AccountNotFoundException();
		}
		
		
	}
	
	
	
	case 2:
	{
		
		
		System.out.println("Enter the mobile number");
		String b= sc.next();
		System.out.println("Enter the Amount");
		int k = sc.nextInt();
		if(b.equals("9010210131")||b.equals("9823920123")||b.equals("9932012345")||b.equals("9010210132")||b.equals("90102101033"))
		{
			
	System.out.println(service.rechargeAccount(b, k));
	}
		else
		{
			System.out.println("Error");
		}
	}
	
	
	case 3:
	{
		System.exit(0);
	}
	
	}
	}
}
	
	
	


